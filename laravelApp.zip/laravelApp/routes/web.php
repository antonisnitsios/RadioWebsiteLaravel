<?php

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Auth;

Auth::Routes();
Route::get('/', 'HomeController@myindex')->name('home');
Route::get('/create', 'HomeController@index')->name('createdata');
Route::get('/home', 'HomeController@index')->name('create');
Route::resource('attribute', 'PostController');
Route::get('/favourites', 'SelectRadioController@getFavourites')->name('favourites');
Route::get('attribute/destroy/{id}', 'PostController@destroy');
Route::get('attribute/edit/{id}' , 'PostController@edit');
Route::get('attribute/update/{id}' , 'PostController@update');
Route::resource('radio', 'RadioController');
Route::get('radio/show/{id}','RadioController@show');
Route::get('radio/destroy/{id}', 'RadioController@destroy');
Route::get('/store', 'RadioController@store')->name('store');
Route::get('/radioname', 'RadioController@index')->name('radioname');
Route::get('/radiocategory', 'RadioController@indexbycategory')->name('radiocategory');
Route::get('/radiocity', 'RadioController@indexbyradiocity')->name('radiocity');
Route::get('/selectradio', 'SelectRadioController@addToFavourites')->name('selectradio');
Route::get('/selectradio/getcategory/{category}', 'SelectRadioController@getcategory');
Route::get('/selectradio/getcity/{city}', 'SelectRadioController@getcity');
Route::get('/internetradios', 'SelectRadioController@getInternetRadio')->name('internetradios');
Route::get('/radios', 'SelectRadioController@searchRadio')->name('radios');
Route::get('/image', 'RadioController@displayImage')->name('displayImage');
Route::get('/imagedisplay', 'RadioController@imagedisplay')->name('image');
?>
