@extends('layouts.app')
<link rel="stylesheet" href="//www.radiojar.com/wrappers/api-plugins/v1/css/player.css">

@section('title')
    @foreach($id as $str)
        {{$str->radioname}}
    @endforeach
@endsection

@section('content')
<div style="background-image: url('/storage/images/radio.jpg'); width:100%; background-repeat: repeat;"/>
<div class="container-fluid" style="color:white; min-width:600px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background-color:rgb(60,179,113); width:700px;">
				<div id="searchbar" style="margin:2em;">
					<h4>Αναζήτηση Σταθμού</h4>
					<form method="get" action="{{route('radios')}}">
						<div class="input-group stylish-input-group">
							<input type="text" id="txtSearch" name="txtSearch" class="form-control"  placeholder="Αναζήτηση σταθμού..." >
							<input type="submit" class="glyphicon glyphicon-search" value="Search" style="background-color:#0000CD; color:white; border-radius:10px;"/>  
						</div>
					</form>
                </div>
				
				<div class="card-header"><b>ΑΚΟΥΣΕ ΤΟ ΣΤΑΘΜΟ ΠΟΥ ΣΟΥ ΤΑΙΡΙΑΖΕΙ</b></div>
                @csrf
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                                      
                    @foreach($id as $str)
                    <center><h2>{{$str->radioname}} {{$str->radiofm}}</h2></center>
                    <div style="float:left; display:block; margin-top:4em; border-radius:2px;">

                        <script type="text/javascript" src="https://hosted.muses.org/mrp.js"></script>
                        <script type="text/javascript">
                        MRP.insert({
                        'url':'{{$str->stream}}',
                        'codec':'mp3',
                        'volume':100,
                        'autoplay':false,
                        'jsevents':true,
                        'buffering':0,
                        'title':'{{$str->radioname}}',
                        'wmode':'transparent',
                        'skin':'alberto',
                        'width':250,
                        'height':95
                        });
                        </script>
                    </div>

					<!--<div style="float:right; margin-top:2em; margin-bottom:2em;">
                        <script type="text/javascript" src="https://hosted.muses.org/mrp.js"></script>
                        <script type="text/javascript">
                        MRP.insert({
                        'url':'{{$str->stream}}',
                        'codec':'mp3',
                        'volume':100,
                        'autoplay':false,
                        'jsevents':true,
                        'buffering':0,
                        'title':'{{$str->radioname}}',
                        'wmode':'transparent',
                        'skin':'simple-red',
                        'width':300,
                        'height':122
                        });
                        </script>
                    </div>
					-->
					
                    <table class="table table-dark" style="min-width:200px; width:200px; margin-top:3em; margin-right:1em; float:right;">
                        <thead>
                        <tr>
                            <th style="font-size: 26px;">ΣΤΟΙΧΕΙΑ ΣΤΑΘΜΟΥ</th>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="row">ΣΤΑΘΜΟΣ</th>  
                            <td scope="row">{{$str->radioname}}</td>
						</tr>
						<tr>
                            <th scope="row">FM</th>
							<td scope="row">{{$str->radiofm}}</td>
						</tr>
						<tr>
							<th scope="row">SITE</th>
                            <td scope="row"><a href="{{$str->link}}" target=_blank>{{$str->link}}</a></td>
						</tr>
						<tr>
							<th scope="row">ΚΑΤΗΓΟΡΙΑ</th>
							<td scope="row">{{$str->category}}</td>
						</tr>
						<tr>
							<th scope="row">ΕΚΠΟΜΠΗ</th>
							<td scope="row">{{$str->address}}</td>
						</tr>
						<tr>
							<th scope="row">ΠΟΛΗ</th>
							<td scope="row">{{$str->city_name}}</td>
                        </tr>
                        </tbody>
                        </table>
                    @endforeach                 
                <hr>           
                </div>               
            </div>
        </div>
    </div>
</div>
</div>
@endsection

