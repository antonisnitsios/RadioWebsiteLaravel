@extends('layouts.app')

@section('title')
  Επεξεργασία Στοιχείων
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>ΠΡΟΣΩΠΙΚΑ ΣΤΟΙΧΕΙΑ</b></div>
                @csrf
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    @if (session('success'))
                    <div class="alert alert-success" role="alert">
                        {{ session('success') }}
                    </div>
                    @endif
                    
                    Τα στοιχεία που έχετε καταχωρήσει υπάρχουν εδώ!
                    Αν δεν έχετε εισάγει ακόμη τα στοιχεία σας μπορείτε να το κάνετε <a href="{{ route('create') }}"><b><em>τώρα</em></b></a>.
                    <div class="row">
                    <div class="col-md-11">
                    <form method="get" action="{{ URL::to('attribute/update/'.Auth::user()->id) }}">
                      @csrf
                      <table class="table table-dark">
                      <thead>
                        <tr>
                          <th scope="col" style="font-size: 24px;">Επεξεργασία στοιχείων</th>
                      </thead>
                      <tbody>@foreach($attributes as $row)
                        <tr>
                          <th scope="row">Τηλέφωνο(υποχρεωτικό):</th>
                          <td><input type="text" maxlength=10 name="phone1" value="{{$row->phone1}}" required></td>
                        </tr>
                        <tr>
                          <th scope="row">Τηλέφωνο(προαιρετικό):</th>
                          <td><input type="text" maxlength=10 name="phone2" value="{{$row->phone2}}" ></td>
                        </tr>
                        <tr>
                          <th scope="row">Facebook προφίλ(link):</th>
                          <td><input type="text" name="facebook" value="{{$row->facebook}}"></td>
                        </tr>
                        <tr>
                          <th scope="row">Linkedin προφίλ(link):</th>
                          <td><input type="text" id="linkedin" value="{{$row->linkedin}}"></td>
                        </tr>
                        <tr>
                          <th scope="row">Επαγγελματική ιδιότητα(υποχρεωτικό):</th>
                          <td><input type="text" name="capacity" value="{{$row->capacity}}"></td>
                        </tr>
                        <tr>
                          <th scope="row">Διεύθυνση κατοικίας:(προαιρετικό)</th>
                          <td><input type="text" name="address" value="{{$row->address}}"></td>
                        </tr>
                        <tr>
                          <th scope="row" hidden>Id:</th>
                          <td><input type="text" name="userid" value="{{ Auth::user()->id }}" hidden></td>
                        </tr>
                        <tr>
                          <th scope="row" hidden>Όνομα Χρήστη:</th>
                          <td><input type="text" name="username" value="{{ Auth::user()->name }}" hidden></td>
                        </tr>
                        <tr>
                          <th scope="row"><input type="submit" class="btn btn-primary" value="Επιβεβαίωση Αλλαγών" style="font-size: 18px; font-weight: bold"/></th>  
                        </tr>@endforeach  
                      </tbody>
                      </table>
                    </form>
                    
                    <ul class="nav">
                      <li class="nav-item" style="">
                        <a class="btn btn-primary" href="{{ route('favourites') }}">Αγαπημένοι Σταθμοί</a>
                      </li>
                      <li class="nav-item" style="margin-left:2px;">
                        <a class="btn btn-primary" href="{{ URL::to('attribute/edit/'.Auth::user()->id) }}">Έπεξεργασία Στοιχείων
                        </a>
                      </li>
                      <li class="nav-item" style="margin-left:2px;">
                         <a class="btn btn-primary" href="{{ URL::to('attribute/destroy/'.Auth::user()->id) }}">Διαγραφή Λογαριασμού
                         </a>
                      </li>
                     </form>
                    </ul>
            </div>
        </div>
    </div>
 </div>   
@endsection
