@extends('layouts.app')

@section('title')
    Αρχική Σελίδα
@endsection

@section('content')
<div class="container-fluid" style="min-width:600px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>ΑΡΧΙΚΗ ΣΕΛΙΔΑ</b></div>
                @csrf
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                    Καλως ήρθατε <b>{{ Auth::user()->name }}</b>!
                    <br/>
                    Είστε συνδεδεμένος! Περιηγηθείτε ελεύθερα, εύκολα και γρήγορα! Ακούστε τον/τους σταθμό/ους που σας αρέσει! Προσθέστε τα στοιχεία σας και τους αγαπημένους σας σταθμούς!                 
                    @if (session('success'))
                    <div class="alert alert-success" role="alert">
                      {{ session('success') }}
                    </div>
                    @endif
                </div>
            </div>
        </div>
    </div>
 </div>
    
@endsection
