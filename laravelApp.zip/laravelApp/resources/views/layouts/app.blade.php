<!doctype html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'LaravelApp')</title>
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="{{ URL::asset('css/styles.css') }}">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="{{ asset('js/app.js') }}" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/core.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
</head>
<body style="background-color:rgb(192,192,192);">
    <div id="app" style="min-width:710px;">
        <nav class="navbar-expand">
            <div class="container-fluid" style="background-color:rgb(160,0,0); min-width:690px; padding:6px; margin:0px; border-radius:12px; display:block; ">
               
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="{{ __('Toggle navigation') }}">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav">
                        <li class="nav-item" style="margin-left: 2px; margin-right: 2px; float:left;">
                            <a class="btn btn-primary" href="{{ route('radio.index') }}">
                            Ραδιοφωνικοί σταθμοί Ελλάδος
                            </a>
                        </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                       	<!-- Authentication Links -->
                        @guest
                            <li class="nav-item">
                                <a class="btn btn-primary" style="margin-left:2px; margin-right:2px; float:left;" href="{{ route('login') }}">{{ __('Σύνδεση') }}</a>
                            </li>
                            @if (Route::has('register'))

                                <li class="nav-item">
                                    <a class="btn btn-primary" href="{{ route('register') }}">{{ __('Εγγραφή') }}</a>
                                </li>
                            @endif
                        @else
                            <li class="nav-item" style="margin-left:2px; margin-right:2px; float:left;">
                                <a class="btn btn-primary" href="{{ route('home') }}">
                                    Αρχική Σελίδα
                                </a>
                            </li>
                            <li class="nav-item" style="margin-left: 2px; margin-right: 2px; ">
                                <a class="btn btn-primary" href="{{ route('attribute.index') }}">
                                    <b><div style="font-size: 20px;">{{ Auth::user()->name }}</div> 
                                        <em>({{ Auth::user()->email }})</em>
                                    </b>
                                </a>
                            </li>
                            <li class="nav-item" style="margin-left: 2px; margin-right: 2px; ">
                                <a class="btn btn-primary" href="{{ route('createdata') }}">
                                    Καταχώρηση στοιχείων
                                </a>
                            </li>
                            <li class="nav-item" style="margin-left: 2px; margin-right: 2px;">
                                <a class="btn btn-primary" href="{{ route('favourites') }}">
                                   Αγαπημένα
                                </a>
                            </li>                   
                            <li class="nav-item">
                                <form id="logout-form" action="{{ route('logout') }}" method="POST" >
                                    @csrf
                                    <button class="btn btn-primary" >
                                        {{ __('Αποσύνδεση') }}
                                    </button>
                                </form>
                            </li>
                            
                            
                        </div>
                            
                        @endguest

                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-2">
            @yield('content')
        </main>
    </div>
</body>
</html>
