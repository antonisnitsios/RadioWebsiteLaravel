@extends('layouts.app')

@section('title')
  Το Προφίλ Μου
@endsection

@section('content')
<div class="container-fluid" style="min-width:600px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background-color:rgb(192,192,192);">
                <div class="card-header"><b>ΠΡΟΣΩΠΙΚΑ ΣΤΟΙΧΕΙΑ</b></div>
                @csrf
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    @if (session('success'))
                    <div class="alert alert-success" role="alert">
                        {{ session('success') }}
                    </div>
                    @endif
                    
                    Τα στοιχεία που έχετε καταχωρήσει υπάρχουν εδώ!
                    Αν δεν έχετε εισάγει ακόμη τα στοιχεία σας μπορείτε να το κάνετε <a href="{{ route('create') }}"><b><em>τώρα</em></b></a>.
					<hr>
                    <div class="row">
                      <div class="col-md-11">
                        <table class="table table-dark">
                          <thead>
                            <tr>
                              <th scope="col" style="font-size: 24px;">Προσωπικά στοιχεία</th>
                          </thead>
                          <tbody>@foreach($attributes as $row)
                            <tr>
                              <th scope="row">Όνομα Χρήστη:</th>
                              <td><b>{{ Auth::user()->name }}</b></td>
                            </tr>
                            <tr>
                              <th scope="row">Email:</th>
                              <td><b>{{ Auth::user()->email }}</b></td>
                            </tr>
                            <tr>
                              <th scope="row">Τηλέφωνο 1:</th>
                              <td>{{$row->phone1}}</td>
                            </tr>
                            <tr>
                              <th scope="row">Τηλέφωνο 2:</th>
                              <td>{{$row->phone2}}</td>
                            </tr>
                            <tr>
                              <th scope="row">Facebook προφίλ:</th>
                              <td>{{$row->facebook}}</td>
                            </tr>
                            <tr>
                              <th scope="row">Linkedin προφίλ:</th>
                              <td>{{$row->linkedin}}</td>
                            </tr>
                            <tr>
                              <th scope="row">Επαγγελματική ιδιότητα:</th>
                              <td>{{$row->capacity}}</td>
                            </tr>
                            <tr>
                              <th scope="row">Διεύθυνση κατοικίας:</th>
                              <td>{{$row->address}}</td>
                            </tr> 
                            <tr>
                              <th scope="row">Τελευταία αλλαγή στοιχείων:</th>
                              <td><em>{{ Auth::user()->updated_at }}</em></td>
                            </tr>              
                            <hr>@endforeach  
                           </tbody>
                        </table>
                      </div>
                    </div>
                    
                    <ul class="nav">
                      <li class="nav-item" style="">
                        <a class="btn btn-primary" href="{{ route('favourites') }}">Αγαπημένοι Σταθμοί</a>
                      </li>
                      <li class="nav-item" style="margin-left:2px;">
                        <a class="btn btn-primary" href="{{ URL::to('attribute/edit/'.Auth::user()->id) }}">Έπεξεργασία Στοιχείων
                        </a>
                      </li>
                      <li class="nav-item" style="margin-left:2px;">
                         <a class="btn btn-primary" href="{{ URL::to('attribute/destroy/'.Auth::user()->id) }}">Διαγραφή Λογαριασμού
                         </a>
                      </li>
                     </form>
                    </ul>
            </div>
        </div>
    </div>
 </div>   
@endsection
