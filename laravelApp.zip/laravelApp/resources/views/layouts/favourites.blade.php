@extends('layouts.app')
<link rel="stylesheet" href="//www.radiojar.com/wrappers/api-plugins/v1/css/player.css">

@section('title')
    Αγαπημένα
@endsection

@section('content')
<div style="background-image: url('/storage/images/background.jpg'); min-height: 800px;">
<div class="container-fluid" style="min-width:600px; width:500px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="background-color:rgb(192,192,182); font-size:27px; text-align:center;"><b>ΑΓΑΠΗΜΕΝΑ</b></div>
                @csrf
                <div class="card-body" style="background-color:rgb(192,192,182);">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    @if (session('success'))
                    <div class="alert alert-error" role="alert" style="color:white;">
                        {{ session('success') }}
                    </div>
                    @endif
					<center>
					<div style="background-color:rgb(205,107,0); width:280px; border-radius:4px; display:block; margin-top:12px;">
						@foreach($radios as $str)
						<br>
						<h3><a href="{{ URL::to('radio/show/'.$str->radio_id) }}" style="color:white; font-size:34	px;">{{$str->radio_radioname}}</a>
						</h3>
						<br>
						<button style="background-color:red; border-shadow:0; height:28px; width:180px; border-radius:43px;"><a href="{{ URL::to('radio/destroy/'.$str->id) }}" style="color:white; font-size:11px;">Αφαίρεση από τα αγαπημένα</a></button>
						<hr>
						<br>
					@endforeach
					</div>
                    <br>
					<hr>
					</center>
					
                </div>               
            </div>
        </div>
    </div>
</div>
</div>
@endsection

