@extends('layouts.app')

@section('title')
    Φόρμα Καταχώρησης Στοιχείων
@endsection

@section('content')
<div class="container" style="min-width:640px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background-color:rgb(192,192,192);">
                <div class="card-header"><b>ΚΑΤΑΧΩΡΗΣΗ ΣΤΟΙΧΕΙΩΝ</b></div>
                <div class="row">
                 <div class="col-md-12">
                  <br />
                  @if(count($errors) > 0)
                  <div class="alert alert-danger">
                   <ul>
                   @foreach($errors->all() as $error)
                    <li>{{$error}}</li>
                   @endforeach
                   </ul>
                  </div>
                  @endif

                  @if (session('success'))
                  <div class="alert alert-success" role="alert">
                    {{ session('success') }}
                  </div>
                  @endif

                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif

                    Καλως ήρθατε <b>{{ Auth::user()->name }}</b>
                    <hr>
					        <div class="row">
                  <div class="col-md-6">
					        <form method="post" action="attribute">
                      @csrf
                      <table class="table table-dark" style="min-width:400px;">
                      <thead>
                        <tr>
                          <th scope="col" style="font-size: 24px;">Καταχώρηση στοιχείων</th>
                          <td><img src="storage/images/registerdata.jpg" style="width:120px; height:100px;"></img></td>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">Τηλέφωνο(υποχρεωτικό):</th>
                          <td><input type="text" maxlength=10 name="phone1" required></td>
                        </tr>
                        <tr>
                          <th scope="row">Τηλέφωνο(προαιρετικό):</th>
                          <td><input type="text" maxlength=10 name="phone2" ></td>
                        </tr>
                        <tr>
                          <th scope="row">Facebook προφίλ(link):</th>
                          <td><input type="text" name="facebook" ></td>
                        </tr>
                        <tr>
                          <th scope="row">Linkedin προφίλ(link):</th>
                          <td><input type="text" id="linkedin" ></td>
                        </tr>
                        <tr>
                          <th scope="row">Επαγγελματική ιδιότητα(υποχρεωτικό):</th>
                          <td><input type="text" name="capacity" ></td>
                        </tr>
                        <tr>
                          <th scope="row">Διεύθυνση κατοικίας:(προαιρετικό)</th>
                          <td><input type="text" name="address" ></td>
                        </tr>
                        <tr>
                          <th scope="row" hidden>Id:</th>
                          <td><input type="text" name="userid" value="{{ Auth::user()->id }}" hidden></td>
                        </tr>
                        <tr>
                          <th scope="row" hidden>Όνομα Χρήστη:</th>
                          <td><input type="text" name="username" value="{{ Auth::user()->name }}" hidden></td>
                        </tr>
                        <tr>
                          <th scope="row"><input type="submit" class="btn btn-primary" style="font-size: 18px; font-weight: bold"/></th>  
                        </tr>
                      </tbody>
                      </table>
                    </form>
                  </div>
                  </div>
               </div>
            </div>
        </div>
    </div>
</div>
@endsection
