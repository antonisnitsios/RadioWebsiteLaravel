<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Attribute;
use App\Radio;

class City extends Model
{
    protected $fillable = array('id','city','prefecture','lat','lng','region');
}
