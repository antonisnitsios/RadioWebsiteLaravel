<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\City;
use Illuminate\Support\Facades\Auth;

class CityNameController extends Controller
{
    public function index()
    {
    	$cities = City::orderby('city_name', 'asc')->get();
    	return view('layouts.cities')->with('cities', $cities);
    }

    public function indexbyprefecture()
    {
    	$cities = City::orderby('prefecture', 'asc', 'city_name', 'asc')->get();
    	return view('layouts.cities')->with('cities', $cities);
    }

    public function indexbyregion()
    {
    	$cities = City::orderby('region', 'asc', 'city_name', 'asc')->get();
    	return view('layouts.cities')->with('cities', $cities);
    }

    public function chooseorder(Request $request)
    {	
    	$r = $request->get('ppp');
    	if($r == "cname"){
    		return redirect()->route('cname');
    	}
    	elseif($r == "region") {
    		return redirect()->route('region');	
    	}
    	elseif($r == "prefecture"){
    		return redirect()->route('prefecture');
    	}
    }
}

