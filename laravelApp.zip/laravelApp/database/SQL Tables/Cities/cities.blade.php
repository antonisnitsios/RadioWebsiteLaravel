@extends('layouts.app')

@section('title')
    Πόλεις Ελλάδος
@endsection

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>ΠΕΡΙΟΧΕΣ ΤΗΣ ΕΛΛΑΔΟΣ</b></div>
                @csrf
                <div class="card-body">
                    @if (session('status'))
                        <div class="alert alert-success" role="alert">
                            {{ session('status') }}
                        </div>
                    @endif
                </div>
                <form action="{{route('chooseorder')}}" method="get">
                  @csrf
                  <select name="ppp">
                    <option id="1" value="cname" selected>Ταξινόμηση βάσει Ονόματος Πόλης</a></option>
                    <option id="2" value="prefecture">Ταξινόμηση βάσει Νομού</a></option>
                    <option id="3" value="region">Ταξινόμηση βάσει Περιφέρειας</a></option>
                  </select>
                  <input type="submit" class="btn btn-primary" value="Υποβολή"></button>
                </form>                
                <hr>
                <table class="table table-dark">
                      <thead>
                        <tr>
                          <th scope="col" style="font-size: 24px;">Στοιχεία πόλεων</th>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">ΠΟΛΗ</th>  
                          <th scope="row">ΝΟΜΟΣ</th>
                          <th scope="row">ΠΕΡΙΦΕΡΕΙΑ</th>
                        </tr>
                          @foreach($cities as $row)
                          <td><a>{{$row->city_name}}</a></td>
                          <td><a>{{$row->prefecture}}</a></td>
                          <td><a>{{$row->region}}</a></td>
                          <tr>
                          @endforeach
                       </tbody>
                    </table>
                    
            </div>
        </div>
    </div>
 </div>   
@endsection
