# Cities-of-Greece
This project is a database of all the cities of Greece
