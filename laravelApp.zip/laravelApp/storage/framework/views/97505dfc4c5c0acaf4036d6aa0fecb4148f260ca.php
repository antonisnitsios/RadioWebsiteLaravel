<?php $__env->startSection('title'); ?>
    Ραδιόφωνα Ελλάδος
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="min-width:600px;">
  <?php echo csrf_field(); ?>
    <div class="card-body">
      <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
         <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>  
    </div> 
  <br />
  <?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>
 
  <div id="searchbar" style="margin-bottom:2em; margin-right:16em; margin-top:0;">
  <h4>Αναζήτηση Σταθμού</h4>
  <form method="get" action="<?php echo e(route('radios')); ?>">
	<div class="input-group stylish-input-group">
		<input type="text" id="txtSearch" name="txtSearch" class="form-control"  placeholder="Αναζήτηση σταθμού..." >
		<input type="submit" class="glyphicon glyphicon-search" value="Αναζήτηση" style="background-color:#0000CD; color:white; border-radius:10px; padding:6px;"/>  
	</div>
  </form>
  </div>
  <hr>

  <nav id="radionav" style="padding:0; width:210px; background:#900a00; float:left; min-height:200px; position:relative; clear:both; color:white;"> 
    <ul style="list-style-type:none; margin:1em; padding:0.5em; float:left;">
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <h5>ΕΙΔΗ ΣΤΑΘΜΩΝ</h5>
      </li>
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <a href="<?php echo e(route('radio.index')); ?>" style="color:white;">ΟΛΑ</a>
      </li>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <a href="<?php echo e(URL::to('selectradio/getcategory/'.$cat->category)); ?>" style="color:white;"><?php echo e($cat->category); ?></a>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>     
  </nav>
 
  <nav id="radionav2" style="margin-top:8px; padding:0; width:210px; background:#900a00; float:left; min-height:200px; position:relative; clear:both; color:white;"> 
    <ul style="list-style-type:none; margin:1em; padding:0.5em; float:left;">
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <h5>ΠΕΡΙΟΧΕΣ</h5>
      </li>
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <a href="<?php echo e(route('internetradios')); ?>" style="color:white;">INTERNET RADIOS</a>
      </li>
      <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li style="width:160px; text-align:center; margin: 0px 0 5px 0; padding:2px;">
        <a href="<?php echo e(URL::to('selectradio/getcity/'.$ct->city_name)); ?>" style="color:white;"><?php echo e($ct->city_name); ?></a>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </nav>
  <div class="row">
    <div class="col-md-5">
      <table class="table table-dark table-hover table-condensed">
        <thead>
          <tr>
          <?php $__currentLoopData = $pass; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <th style="font-size: 24px;" colspan=4>Ραδιοφωνικοί Σταθμοί Περιοχή: <?php echo e($data->city_name); ?></th>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </thead>
          <tbody>
          <tr>
            <th scope="col">ΣΤΑΘΜΟΣ</th>
            <th scope="col">FM</th>  
            <th scope="col">ΚΑΤΗΓΟΡΙΑ</th>
            <th scope="col">ΕΚΠΟΜΠΗ</th>
          </tr>
          <?php $__currentLoopData = $radios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td scope="row-4"><a href="<?php echo e(URL::to('radio/show/'.$row->id)); ?>" target=_blank style="color:white;"><?php echo e($row->radioname); ?></a></td>
            <td scope="row" style="width:40%;"><?php echo e($row->radiofm); ?></td>
            <td scope="row"><?php echo e($row->category); ?></td>
            <td scope="row"><?php echo e($row->address); ?></td>
            <tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
    </div>
 
  </div>
</div>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RADIO WEBSITE\laravelApp\resources\views/layouts/ctradio.blade.php ENDPATH**/ ?>