<?php $__env->startSection('title'); ?>
    Ραδιόφωνα Ελλάδος
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>ΠΕΡΙΟΧΕΣ ΤΗΣ ΕΛΛΑΔΟΣ</b></div>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                </div>
                <form action="<?php echo e(route('chooseorder')); ?>" method="get">
                  <?php echo csrf_field(); ?>
                  <select name="ppp">
                    <option id="1" value="cname" selected>Ταξινόμηση βάσει Ονόματος Πόλης</a></option>
                    <option id="2" value="prefecture">Ταξινόμηση βάσει Νομού</a></option>
                    <option id="3" value="region">Ταξινόμηση βάσει Περιφέρειας</a></option>
                  </select>
                  <input type="submit" class="btn btn-primary" value="Υποβολή"></button>
                </form>                
                <hr>
                <table class="table table-dark">
                      <thead>
                        <tr>
                          <th scope="col" style="font-size: 24px;">Στοιχεία πόλεων</th>
                      </thead>
                      <tbody>
                        <tr>
                          <th scope="row">ΠΟΛΗ</th>  
                          <th scope="row">ΝΟΜΟΣ</th>
                          <th scope="row">ΠΕΡΙΦΕΡΕΙΑ</th>
                        </tr>
                          <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <td><a><?php echo e($row->city_name); ?></a></td>
                          <td><a><?php echo e($row->prefecture); ?></a></td>
                          <td><a><?php echo e($row->region); ?></a></td>
                          <tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                       </tbody>
                    </table>
                    
            </div>
        </div>
    </div>
 </div>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/layouts/cities.blade.php ENDPATH**/ ?>