<?php $__env->startSection('title'); ?>
  Επεξεργασία Στοιχείων
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>ΠΡΟΣΩΠΙΚΑ ΣΤΟΙΧΕΙΑ</b></div>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                    
                    Τα στοιχεία που έχετε καταχωρήσει υπάρχουν εδώ!
                    Αν δεν έχετε εισάγει ακόμη τα στοιχεία σας μπορείτε να το κάνετε <a href="<?php echo e(route('create')); ?>"><b><em>τώρα</em></b></a>.
                    <div class="row">
                    <div class="col-md-11">
                    <form method="get" action="<?php echo e(URL::to('attribute/update/'.Auth::user()->id)); ?>">
                      <?php echo csrf_field(); ?>
                      <table class="table table-dark">
                      <thead>
                        <tr>
                          <th scope="col" style="font-size: 24px;">Επεξεργασία στοιχείων</th>
                      </thead>
                      <tbody><?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                          <th scope="row">Τηλέφωνο(υποχρεωτικό):</th>
                          <td><input type="text" maxlength=10 name="phone1" value="<?php echo e($row->phone1); ?>" required></td>
                        </tr>
                        <tr>
                          <th scope="row">Τηλέφωνο(προαιρετικό):</th>
                          <td><input type="text" maxlength=10 name="phone2" value="<?php echo e($row->phone2); ?>" ></td>
                        </tr>
                        <tr>
                          <th scope="row">Facebook προφίλ(link):</th>
                          <td><input type="text" name="facebook" value="<?php echo e($row->facebook); ?>"></td>
                        </tr>
                        <tr>
                          <th scope="row">Linkedin προφίλ(link):</th>
                          <td><input type="text" id="linkedin" value="<?php echo e($row->linkedin); ?>"></td>
                        </tr>
                        <tr>
                          <th scope="row">Επαγγελματική ιδιότητα(υποχρεωτικό):</th>
                          <td><input type="text" name="capacity" value="<?php echo e($row->capacity); ?>"></td>
                        </tr>
                        <tr>
                          <th scope="row">Διεύθυνση κατοικίας:(προαιρετικό)</th>
                          <td><input type="text" name="address" value="<?php echo e($row->address); ?>"></td>
                        </tr>
                        <tr>
                          <th scope="row" hidden>Id:</th>
                          <td><input type="text" name="userid" value="<?php echo e(Auth::user()->id); ?>" hidden></td>
                        </tr>
                        <tr>
                          <th scope="row" hidden>Όνομα Χρήστη:</th>
                          <td><input type="text" name="username" value="<?php echo e(Auth::user()->name); ?>" hidden></td>
                        </tr>
                        <tr>
                          <th scope="row"><input type="submit" class="btn btn-primary" value="Επιβεβαίωση Αλλαγών" style="font-size: 18px; font-weight: bold"/></th>  
                        </tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                      </tbody>
                      </table>
                    </form>
                    
                    <ul class="nav">
                      <li class="nav-item" style="">
                        <a class="btn btn-primary" href="<?php echo e(route('favourites')); ?>">Αγαπημένοι Σταθμοί</a>
                      </li>
                      <li class="nav-item" style="margin-left:2px;">
                        <a class="btn btn-primary" href="<?php echo e(URL::to('attribute/edit/'.Auth::user()->id)); ?>">Έπεξεργασία Στοιχείων
                        </a>
                      </li>
                      <li class="nav-item" style="margin-left:2px;">
                         <a class="btn btn-primary" href="<?php echo e(URL::to('attribute/destroy/'.Auth::user()->id)); ?>">Διαγραφή Λογαριασμού
                         </a>
                      </li>
                     </form>
                    </ul>
            </div>
        </div>
    </div>
 </div>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/layouts/update.blade.php ENDPATH**/ ?>