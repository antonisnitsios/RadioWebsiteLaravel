<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo e(config('app.name', 'Laravel')); ?></title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script><style>
	#map {
		height: 80%;
		width: 100%;
		float: left;
		margin: 0 0 0 8px;
	}
	html, body {
		height: 100%;
		background: #e3e2e1;
	}
	#button-form{
		float: right;
		clear: both;
		border: 2px solid #e3e2e1;
		border-radius: 14px;
		margin: 0;
	}
	#button{
		float: left;
		padding: 1.4em;
		background: #800a00;
		border: 2px solid #e3e2e1;
		border-radius: 13px;
	}
	h2{
		margin:1.4em;
	}
	.modal-content{
		background-color: #800a00;
		color:black;
	}
	#form{
		margin: 0 19em;
	}
	#submit{
		margin: 0 8em;
		padding: 1em 2em;
	}
	#tbody{
		height:40px;
		font-size:18px;
		clear:both;
		padding:2.5em;
	}
	</style>
	<script async defer src="https://maps.googleapis.com/maps/api/js?callback=initMap"></script>
        <script>
            var jsonhttp=new XMLHttpRequest();
            var map;
            jsonhttp.open("GET", "api/cities", true);
            jsonhttp.send(); 
            jsonhttp.onreadystatechange = function(){
                if(jsonhttp.readyState==4 && jsonhttp.status==200){
                    initMap(this);
                }
            };

            function initMap(obj) {
                var mapOptions = {
                    zoom: 10,
                    center: new google.maps.LatLng( 39.641309, 22.417800 ),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };
                
                var obj = JSON.parse(jsonhttp.response);
                var jsondata = obj.cities;
                
                map = new google.maps.Map(document.getElementById('map'), mapOptions);
                                
                for(var i=0; i<jsondata.length; i++){
                    var json=jsondata[i];
                    var lat=json.lat;
                    var lng=json.lng;
                    var id=json.id;
                    var city_name=json.city_name;
                    var marker = new google.maps.Marker({
                        map: map,
                        position: new google.maps.LatLng(lat,lng),
                        title: json.city_name,
                        postitle: center,
                        draggable: true,
                        mapTypeControl: true    
                    });
                    var clicker = addClicker(marker, city_name);
                }
                var infowindow = new google.maps.InfoWindow({
                    content: marker.postitle
                });
                marker.addListener('click', function() {
                    infowindow.open(map, marker);
                });
              
                function addClicker(marker) {
                    google.maps.event.addListener(marker, 'click', function() { 
                    if (infowindow) {infowindow.close()}        
                        infowindow = new google.maps.InfoWindow({content: marker.postitle});
                        infowindow.open(map, marker);
                    });
                }
                function zoomExtends() {
                    //ορίζουμε ένα object-ορθογώνιο (για να ζουμάρουμε μετά πάνω του)
                    var bounds = new google.maps.LatLngBounds();
                    for (var i = 0; i < markers.length; i++) {
                        bounds.extend(markers[i].position);
                    }
                    map.fitBounds(bounds);
                }
            }
            google.maps.event.addDomListener(window, 'click', initialize);
        </script>
</head>
	
	
<body>
<header id="header"></header>

<div class="container">

<div class="row">
	<div class="col-sm-1">
		<div id="button-form" >
		</div>
	</div>
    <div class="col-sm-4"><button id="button" type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myMod"></button></div>
</div>

<div class="modal fade" id="myModal" role="dialog">
	
</div>

<div id="tbody">
<h4>ΣΤΟΙΧΕΙΑ ΣΥΝΟΛΟΥ ΠΡΑΤΗΡΙΩΝ</h4>
</div>
<br/><br/><br/>

<div id="map"></div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/layouts/map.blade.php ENDPATH**/ ?>