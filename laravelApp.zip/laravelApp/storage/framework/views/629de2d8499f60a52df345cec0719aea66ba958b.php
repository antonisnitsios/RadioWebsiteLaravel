<?php $__env->startSection('title'); ?>
    Αρχική Σελίδα
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>ΑΡΧΙΚΗ ΣΕΛΙΔΑ</b></div>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
                    Καλως ήρθατε <b><?php echo e(Auth::user()->name); ?></b>!
                    <br/>
                    Είστε συνδεδεμένος! Περιηγηθείτε ελεύθερα, εύκολα και γρήγορα!                    
                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                      <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
 </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/layouts/my.blade.php ENDPATH**/ ?>