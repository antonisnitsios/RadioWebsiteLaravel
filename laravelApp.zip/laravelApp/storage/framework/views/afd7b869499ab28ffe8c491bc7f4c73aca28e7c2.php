<!DOCTYPE html>
<html lang="en">
<head>
	<?php echo $__env->make('includes.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<style>
	<?php echo $__env->make('includes.style', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</style>
</head>
<body>
<button onclick="topFunction()" id="myBtn" title="Go to top">Top</button>

<div class="jumbotron">
	<?php echo $__env->make('includes.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>	
</div>	

<nav class="navbar navbar-default">
	<?php echo $__env->make('includes.menu', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</nav>
<div class="container">
	<?php echo $__env->make('includes.container', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
<footer class="text-center">
	<?php echo $__env->make('includes.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</footer>

</body>
</html>
<?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/welcome.blade.php ENDPATH**/ ?>