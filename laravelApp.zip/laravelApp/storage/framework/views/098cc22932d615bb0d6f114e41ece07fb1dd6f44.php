<?php $__env->startSection('title'); ?>
    Ραδιόφωνα Ελλάδος
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.0/jquery.min.js"></script>
<div class="container-fluid" style="min-width:100px;">
  <?php echo csrf_field(); ?>
    <div class="card-body">
      <?php if(session('status')): ?>
        <div class="alert alert-success" role="alert">
         <?php echo e(session('status')); ?>

        </div>
      <?php endif; ?>  
    </div> 
  <br />
  <?php if(count($errors) > 0): ?>
  <div class="alert alert-danger">
    <ul>
      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li><?php echo e($error); ?></li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </div>
  <?php endif; ?>

  <?php if(session('success')): ?>
    <div class="alert alert-success" role="alert">
      <?php echo e(session('success')); ?>

    </div>
  <?php endif; ?> 

  <div id="searchbar" style="margin-bottom:2em; margin-right:16em; margin-top:0;">
  <h4>Αναζήτηση Σταθμού</h4>
  <form method="get" action="<?php echo e(route('radios')); ?>">
	<div class="input-group stylish-input-group">
		<input type="text" id="txtSearch" name="txtSearch" class="form-control"  placeholder="Αναζήτηση σταθμού..." >
		<input type="submit" class="glyphicon glyphicon-search" value="Αναζήτηση" style="background-color:#0000CD; color:white; border-radius:10px; padding:6px;"/>  
	</div>
  </form>
  </div>

  <hr>
  <nav id="radionav" style="padding:0; width:210px; background:#900a00; float:left; min-height:200px; min-width:80px; display:block; position:relative; clear:both; color:white;"> 
    <ul style="list-style-type:none; margin:1em; padding:0.5em; float:left;">
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <h5>ΕΙΔΗ ΣΤΑΘΜΩΝ</h5>
      </li>      
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <a href="<?php echo e(route('radio.index')); ?>" style="color:white;">ΟΛΑ</a>
      </li>
      <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <a href="<?php echo e(URL::to('selectradio/getcategory/'.$cat->category)); ?>" style="color:white;"><?php echo e($cat->category); ?></a>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>     
  </nav>
 
  <nav id="radionav2" style="margin-top:8px; padding:0; width:210px; background:#900a00; float:left; min-height:200px; min-width:80px; display:block; position:relative; clear:both; color:white;"> 
    <ul style="list-style-type:none; margin:1em; padding:0.5em; float:left;">
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <h5>ΠΕΡΙΟΧΕΣ</h5>
      </li>
      <li style="width:150px; text-align:center; margin: 0 0 2px 0; padding:1px;">
        <a href="<?php echo e(route('internetradios')); ?>" style="color:white;">INTERNET RADIOS</a>
      </li>
      <?php $__currentLoopData = $cities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ct): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <li style="width:160px; text-align:center; margin: 0px 0 5px 0; padding:2px;">
        <a href="<?php echo e(URL::to('selectradio/getcity/'.$ct->city_name)); ?>" style="color:white;"><?php echo e($ct->city_name); ?></a>
      </li>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </ul>
  </nav>
  <div class="row">
    <div class="col-md-4">
      <form action="<?php echo e(route('store')); ?>" method="get" style="margin-bottom:1em;">
        <select name="ppp">
          <option id="1" value="radioname" selected>Ταξινόμηση βάσει Ονόματος</a></option>
          <option id="2" value="radiocategory">Ταξινόμηση βάσει Κατηγορίας</a></option>
          <option id="3" value="radiocity">Ταξινόμηση βάσει Τοποθεσίας</a></option>
        </select>
        <input type="submit" class="btn btn-primary" value="Υποβολή"></button>
      </form>            

      <table class="table table-dark table-hover table-condensed" style="min-width:330px; display:block;">
        <thead>
          <tr>
          <th style="font-size: 24px;" colspan=4>Ραδιοφωνικοί Σταθμοί Ελλάδος</th>
          </thead>
          <tbody>
          <tr>
            <th scope="col">ΣΤΑΘΜΟΣ</th>
            <th scope="col">FM</th>  
            <th scope="col">ΚΑΤΗΓΟΡΙΑ</th>   
          </tr>
          <?php $__currentLoopData = $radios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td scope="row-4"><a href="<?php echo e(URL::to('radio/show/'.$row->id)); ?>" target=_blank style="color:white;"><?php echo e($row->radioname); ?></a></td>
            <td scope="row" style="width:40%;"><?php echo e($row->radiofm); ?></td>
            <td scope="row"><?php echo e($row->category); ?></td>
            <tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
      </table>
    </div>

    <div class="col-md-4">
      <table class="table table-dark table-hover table-condensed" style="margin-top:3.3em; margin-left:5em; min-width:250px; display:block;">
        <thead>          
        <tr>
          <th scope="col" style="font-size: 24px;" colspan=4>Web Radio Σταθμοί</th>
        </thead>
        <tbody>
        <tr>
            <th scope="col">ΣΤΑΘΜΟΣ</th>  
            <th scope="col">ΕΚΠΟΜΠΗ</th>
        </tr>
        <?php $__currentLoopData = $internetradios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $irow): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <td scope="row" style="width:45%;"><a href="<?php echo e(URL::to('radio/show/'.$irow->id)); ?>" target=_blank style="color:white;"> <?php echo e($irow->radioname); ?> </a></td>
            <td scope="row"><?php echo e($irow->address); ?></td>
            <tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
      </table>
    </div>
  </div>
</div>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RADIO WEBSITE\laravelApp\resources\views/layouts/radio.blade.php ENDPATH**/ ?>