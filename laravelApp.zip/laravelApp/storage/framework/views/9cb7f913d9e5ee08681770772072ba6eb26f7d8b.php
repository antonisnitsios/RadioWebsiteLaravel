  <div class="container-fluid" style="background-color: #851E08;">
    <div class="navbar-header">
      <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#myNavbar">
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>
        <span class="icon-bar"></span>                        
      </button>
    </div>
    <div class="collapse navbar-collapse" id="myNavbar">
      <ul class="nav navbar-nav">
        <li><a href="#" style="color: #FFFFFF;">Home</a></li>
        <li><a href="#" style="color: #FFFFFF;">Page 1</a></li>
        <li><a href="#" style="color: #FFFFFF;">Page 2</a></li>
        <li><a href="#" style="color: #FFFFFF;">Page 3</a></li>
      </ul>
      
    </div>
  </div>
<?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/includes/menu.blade.php ENDPATH**/ ?>