<div class="text-right">
<h1>WebSiteName</h1>    
<?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/includes/header.blade.php ENDPATH**/ ?>