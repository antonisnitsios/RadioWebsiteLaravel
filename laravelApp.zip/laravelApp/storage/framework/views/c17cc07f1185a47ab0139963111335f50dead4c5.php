<link rel="stylesheet" href="//www.radiojar.com/wrappers/api-plugins/v1/css/player.css">

<?php $__env->startSection('title'); ?>
    Αγαπημένα
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>ΑΚΟΥΣΕ ΤΟ ΔΩΡΕΑΝ</b></div>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-error" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>

                    <?php $__currentLoopData = $radios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $str): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h3><a href="<?php echo e(URL::to('radio/show/'.$str->radio_id)); ?>" style="color:blue;"><?php echo e($str->radio_radioname); ?></a>
                    </h3>
                    <a href="<?php echo e(URL::to('radio/destroy/'.$str->id)); ?>" style="color:darkred; font-size:11px;">Delete radio
                    </a>
                    <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <hr>
                    
                </div>               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/layouts/favourites.blade.php ENDPATH**/ ?>