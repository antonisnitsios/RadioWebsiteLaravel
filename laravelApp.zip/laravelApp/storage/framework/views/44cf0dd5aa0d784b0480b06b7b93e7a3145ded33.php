<link rel="stylesheet" href="//www.radiojar.com/wrappers/api-plugins/v1/css/player.css">

<?php $__env->startSection('title'); ?>
    Αγαπημένα
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('/storage/images/background.jpg'); min-height: 800px;">
<div class="container-fluid" style="min-width:600px; width:500px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header" style="background-color:rgb(192,192,182); font-size:27px; text-align:center;"><b>ΑΓΑΠΗΜΕΝΑ</b></div>
                <?php echo csrf_field(); ?>
                <div class="card-body" style="background-color:rgb(192,192,182);">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-error" role="alert" style="color:white;">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
					<center>
					<div style="background-color:rgb(205,107,0); width:280px; border-radius:4px; display:block; margin-top:12px;">
						<?php $__currentLoopData = $radios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $str): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<br>
						<h3><a href="<?php echo e(URL::to('radio/show/'.$str->radio_id)); ?>" style="color:white; font-size:34	px;"><?php echo e($str->radio_radioname); ?></a>
						</h3>
						<br>
						<button style="background-color:red; border-shadow:0; height:28px; width:180px; border-radius:43px;"><a href="<?php echo e(URL::to('radio/destroy/'.$str->id)); ?>" style="color:white; font-size:11px;">Αφαίρεση από τα αγαπημένα</a></button>
						<hr>
						<br>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
                    <br>
					<hr>
					</center>
					
                </div>               
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RADIO WEBSITE\laravelApp\resources\views/layouts/favourites.blade.php ENDPATH**/ ?>