<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'LaravelApp'); ?></title>
    <link rel="dns-prefetch" href="//fonts.gstatic.com">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/styles.css')); ?>">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/core.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.js"></script>
</head>
<body style="background-color:rgb(192,192,192);">
    <div id="app" style="min-width:710px;">
        <nav class="navbar-expand">
            <div class="container-fluid" style="background-color:rgb(160,0,0); min-width:690px; padding:6px; margin:0px; border-radius:12px; display:block; ">
               
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="<?php echo e(__('Toggle navigation')); ?>">
                    <span class="navbar-toggler-icon"></span>
                </button>

                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <!-- Left Side Of Navbar -->
                    <ul class="navbar-nav">
                        <li class="nav-item" style="margin-left: 2px; margin-right: 2px; float:left;">
                            <a class="btn btn-primary" href="<?php echo e(route('radio.index')); ?>">
                            Ραδιοφωνικοί σταθμοί Ελλάδος
                            </a>
                        </li>
                    </ul>

                    <!-- Right Side Of Navbar -->
                    <ul class="navbar-nav ml-auto">
                       	<!-- Authentication Links -->
                        <?php if(auth()->guard()->guest()): ?>
                            <li class="nav-item">
                                <a class="btn btn-primary" style="margin-left:2px; margin-right:2px; float:left;" href="<?php echo e(route('login')); ?>"><?php echo e(__('Σύνδεση')); ?></a>
                            </li>
                            <?php if(Route::has('register')): ?>

                                <li class="nav-item">
                                    <a class="btn btn-primary" href="<?php echo e(route('register')); ?>"><?php echo e(__('Εγγραφή')); ?></a>
                                </li>
                            <?php endif; ?>
                        <?php else: ?>
                            <li class="nav-item" style="margin-left:2px; margin-right:2px; float:left;">
                                <a class="btn btn-primary" href="<?php echo e(route('home')); ?>">
                                    Αρχική Σελίδα
                                </a>
                            </li>
                            <li class="nav-item" style="margin-left: 2px; margin-right: 2px; ">
                                <a class="btn btn-primary" href="<?php echo e(route('attribute.index')); ?>">
                                    <b><div style="font-size: 20px;"><?php echo e(Auth::user()->name); ?></div> 
                                        <em>(<?php echo e(Auth::user()->email); ?>)</em>
                                    </b>
                                </a>
                            </li>
                            <li class="nav-item" style="margin-left: 2px; margin-right: 2px; ">
                                <a class="btn btn-primary" href="<?php echo e(route('createdata')); ?>">
                                    Καταχώρηση στοιχείων
                                </a>
                            </li>
                            <li class="nav-item" style="margin-left: 2px; margin-right: 2px;">
                                <a class="btn btn-primary" href="<?php echo e(route('favourites')); ?>">
                                   Αγαπημένα
                                </a>
                            </li>                   
                            <li class="nav-item">
                                <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" >
                                    <?php echo csrf_field(); ?>
                                    <button class="btn btn-primary" >
                                        <?php echo e(__('Αποσύνδεση')); ?>

                                    </button>
                                </form>
                            </li>
                            
                            
                        </div>
                            
                        <?php endif; ?>

                    </ul>
                </div>
            </div>
        </nav>
        <main class="py-2">
            <?php echo $__env->yieldContent('content'); ?>
        </main>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\RADIO WEBSITE\laravelApp\resources\views/layouts/app.blade.php ENDPATH**/ ?>