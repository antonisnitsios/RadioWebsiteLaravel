<link rel="stylesheet" href="//www.radiojar.com/wrappers/api-plugins/v1/css/player.css">
<?php $__env->startSection('title'); ?>
    <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $str): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($str->radioname); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div style="background-image: url('/storage/images/radio.jpg'); width:100%; background-repeat: repeat;"/>
<div class="container-fluid" style="color:white; min-width:600px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background-color:rgb(60,179,113); width:700px;">
				<div id="searchbar" style="margin:2em;">
					<h4>Αναζήτηση Σταθμού</h4>
					<form method="get" action="<?php echo e(route('radios')); ?>">
						<div class="input-group stylish-input-group">
							<input type="text" id="txtSearch" name="txtSearch" class="form-control"  placeholder="Αναζήτηση σταθμού..." >
							<input type="submit" value="Αναζήτηση" style="background-color:#0000CD; color:white; border-radius:20px;"/>
						</div>
					</form>
                </div>
			
                <div class="card-header"><b>ΑΚΟΥΣΕ ΤΟ ΣΤΑΘΜΟ ΠΟΥ ΣΟΥ ΤΑΙΡΙΑΖΕΙ</b></div>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert" style="color:red;">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                   
                    <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $str): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <center><h2><?php echo e($str->radioname); ?> <?php echo e($str->radiofm); ?></h2></center>
                    <form id="favourite" action="/selectradio" method="get">
                        <input type="text" name="id" value="<?php echo e($str->id); ?>" hidden/>
                        <input type="text" name="radioname" value="<?php echo e($str->radioname); ?>" hidden/>
                        <input type="text" name="userid" value= " <?php echo e(Auth::user()->id); ?>" hidden/>
                        <input type="text" name="username" value= " <?php echo e(Auth::user()->name); ?>" hidden/>
                        <input type="submit" value="Προσθήκη στα αγαπημένα" class="btn btn-primary"></input>
                    </form>

                    <div style="float:left; margin-top:2em; margin-bottom:2em; border-radius:2px;">
                        <script type="text/javascript" src="https://hosted.muses.org/mrp.js"></script>
                        <script type="text/javascript">
                        MRP.insert({
                        'url':'<?php echo e($str->stream); ?>',
                        'codec':'mp3',
                        'volume':100,
                        'autoplay':false,
                        'jsevents':true,
                        'buffering':0,
                        'title':'<?php echo e($str->radioname); ?>',
                        'wmode':'transparent',
                        'skin':'alberto',
                        'width':250,
                        'height':95
                        });
                        </script>
                    </div>

                   <!--<div style="float:right; margin-top:2em; margin-bottom:2em;">
                        <script type="text/javascript" src="https://hosted.muses.org/mrp.js"></script>
                        <script type="text/javascript">
                        MRP.insert({
                        'url':'<?php echo e($str->stream); ?>',
                        'codec':'mp3',
                        'volume':100,
                        'autoplay':false,
                        'jsevents':true,
                        'buffering':0,
                        'title':'<?php echo e($str->radioname); ?>',
                        'wmode':'transparent',
                        'skin':'simple-red',
                        'width':300,
                        'height':122
                        });
                        </script>
                    </div>-->
                    
                    <table class="table table-dark" style="min-width:200px; width:200px; margin-top:3em; margin-right:1em; float:right;">
                        <thead>
                        <tr>
                            <th style="font-size: 26px;"></th>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="row">ΣΤΑΘΜΟΣ</th>  
                            <td scope="row"><?php echo e($str->radioname); ?></td>
						</tr>
						<tr>
                            <th scope="row">FM</th>
							<td scope="row"><?php echo e($str->radiofm); ?></td>
						</tr>
						<tr>
							<th scope="row">SITE</th>
                            <td scope="row"><a href="<?php echo e($str->link); ?>" target=_blank><?php echo e($str->link); ?></a></td>
						</tr>
						<tr>
							<th scope="row">ΚΑΤΗΓΟΡΙΑ</th>
							<td scope="row"><?php echo e($str->category); ?></td>
						</tr>
						<tr>
							<th scope="row">ΕΚΠΟΜΠΗ</th>
							<td scope="row"><?php echo e($str->address); ?></td>
						</tr>
						<tr>
							<th scope="row">ΠΟΛΗ</th>
							<td scope="row"><?php echo e($str->city_name); ?></td>
                        </tr>
                        </tbody>
                        </table>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                <hr>
                </div>               
            </div>
        </div>
    </div>
</div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RADIO WEBSITE\laravelApp\resources\views/layouts/playradio.blade.php ENDPATH**/ ?>