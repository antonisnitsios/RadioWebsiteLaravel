<?php $__env->startSection('title'); ?>
  Το Προφίλ Μου
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container-fluid" style="min-width:600px;">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card" style="background-color:rgb(192,192,192);">
                <div class="card-header"><b>ΠΡΟΣΩΠΙΚΑ ΣΤΟΙΧΕΙΑ</b></div>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                    
                    Τα στοιχεία που έχετε καταχωρήσει υπάρχουν εδώ!
                    Αν δεν έχετε εισάγει ακόμη τα στοιχεία σας μπορείτε να το κάνετε <a href="<?php echo e(route('create')); ?>"><b><em>τώρα</em></b></a>.
					<hr>
                    <div class="row">
                      <div class="col-md-11">
                        <table class="table table-dark">
                          <thead>
                            <tr>
                              <th scope="col" style="font-size: 24px;">Προσωπικά στοιχεία</th>
                          </thead>
                          <tbody><?php $__currentLoopData = $attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                              <th scope="row">Όνομα Χρήστη:</th>
                              <td><b><?php echo e(Auth::user()->name); ?></b></td>
                            </tr>
                            <tr>
                              <th scope="row">Email:</th>
                              <td><b><?php echo e(Auth::user()->email); ?></b></td>
                            </tr>
                            <tr>
                              <th scope="row">Τηλέφωνο 1:</th>
                              <td><?php echo e($row->phone1); ?></td>
                            </tr>
                            <tr>
                              <th scope="row">Τηλέφωνο 2:</th>
                              <td><?php echo e($row->phone2); ?></td>
                            </tr>
                            <tr>
                              <th scope="row">Facebook προφίλ:</th>
                              <td><?php echo e($row->facebook); ?></td>
                            </tr>
                            <tr>
                              <th scope="row">Linkedin προφίλ:</th>
                              <td><?php echo e($row->linkedin); ?></td>
                            </tr>
                            <tr>
                              <th scope="row">Επαγγελματική ιδιότητα:</th>
                              <td><?php echo e($row->capacity); ?></td>
                            </tr>
                            <tr>
                              <th scope="row">Διεύθυνση κατοικίας:</th>
                              <td><?php echo e($row->address); ?></td>
                            </tr> 
                            <tr>
                              <th scope="row">Τελευταία αλλαγή στοιχείων:</th>
                              <td><em><?php echo e(Auth::user()->updated_at); ?></em></td>
                            </tr>              
                            <hr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
                           </tbody>
                        </table>
                      </div>
                    </div>
                    
                    <ul class="nav">
                      <li class="nav-item" style="">
                        <a class="btn btn-primary" href="<?php echo e(route('favourites')); ?>">Αγαπημένοι Σταθμοί</a>
                      </li>
                      <li class="nav-item" style="margin-left:2px;">
                        <a class="btn btn-primary" href="<?php echo e(URL::to('attribute/edit/'.Auth::user()->id)); ?>">Έπεξεργασία Στοιχείων
                        </a>
                      </li>
                      <li class="nav-item" style="margin-left:2px;">
                         <a class="btn btn-primary" href="<?php echo e(URL::to('attribute/destroy/'.Auth::user()->id)); ?>">Διαγραφή Λογαριασμού
                         </a>
                      </li>
                     </form>
                    </ul>
            </div>
        </div>
    </div>
 </div>   
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\RADIO WEBSITE\laravelApp\resources\views/layouts/created.blade.php ENDPATH**/ ?>