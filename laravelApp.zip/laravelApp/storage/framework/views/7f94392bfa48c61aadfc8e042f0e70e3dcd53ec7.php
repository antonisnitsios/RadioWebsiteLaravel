<p style="font-size: 13px;">Copyright © 2020 | All Rights Reserved</p>
<?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/includes/footer.blade.php ENDPATH**/ ?>