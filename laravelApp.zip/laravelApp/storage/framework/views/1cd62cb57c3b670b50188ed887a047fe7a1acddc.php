<?php $__env->startSection('content'); ?>
<div class="container">
	<div id="map"></div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/map.blade.php ENDPATH**/ ?>