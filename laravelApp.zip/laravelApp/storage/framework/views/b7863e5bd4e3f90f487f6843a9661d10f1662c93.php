<link rel="stylesheet" href="//www.radiojar.com/wrappers/api-plugins/v1/css/player.css">

<?php $__env->startSection('title'); ?>
    <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $str): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($str->radioname); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><b>ΑΚΟΥΣΕ ΤΟ ΔΩΡΕΑΝ</b></div>
                <?php echo csrf_field(); ?>
                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <?php if(session('success')): ?>
                    <div class="alert alert-success" role="alert">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                                      
                    <?php $__currentLoopData = $id; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $str): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <center><h2><?php echo e($str->radioname); ?> <?php echo e($str->radiofm); ?></h2></center>
                    <form action="/selectradio" method="get">
                        <input type="text" name="id" value="<?php echo e($str->id); ?>" hidden/>
                        <input type="text" name="radioname" value="<?php echo e($str->radioname); ?>" hidden/>
                        <input type="text" name="userid" value= " <?php echo e(Auth::user()->id); ?>" hidden/>
                        <input type="text" name="username" value= " <?php echo e(Auth::user()->name); ?>" hidden/>
                        <input type="submit" class="btn btn-success" value="Add to Favourites"> 
                    </form>

                    <div style="float:left; margin-top:2em; margin-bottom:2em; border-radius:2px;">

                        <script type="text/javascript" src="https://hosted.muses.org/mrp.js"></script>
                        <script type="text/javascript">
                        MRP.insert({
                        'url':'<?php echo e($str->stream); ?>',
                        'codec':'mp3',
                        'volume':100,
                        'autoplay':false,
                        'jsevents':true,
                        'buffering':0,
                        'title':'<?php echo e($str->radioname); ?>',
                        'wmode':'transparent',
                        'skin':'alberto',
                        'width':250,
                        'height':95
                        });
                        </script>
                    </div>

                   <div style="float:right; margin-top:2em; margin-bottom:2em;">
                        <script type="text/javascript" src="https://hosted.muses.org/mrp.js"></script>
                        <script type="text/javascript">
                        MRP.insert({
                        'url':'<?php echo e($str->stream); ?>',
                        'codec':'mp3',
                        'volume':100,
                        'autoplay':false,
                        'jsevents':true,
                        'buffering':0,
                        'title':'<?php echo e($str->radioname); ?>',
                        'wmode':'transparent',
                        'skin':'simple-red',
                        'width':300,
                        'height':122
                        });
                        </script>
                    </div>
                    <hr>
                    <table class="table table-dark">
                        <thead>
                        <tr>
                            <th style="font-size: 24px;"></th>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="col">ΣΤΑΘΜΟΣ</th>  
                            <th scope="col">FM</th>
                            <th scope="col">SITE</th>
                            <th scope="col">ΚΑΤΗΓΟΡΙΑ</th>
                            <th scope="col">ΕΚΠΟΜΠΗ</th>
                            <th scope="col">ΠΟΛΗ</th>
                        </tr>
                            <td scope="row"><?php echo e($str->radioname); ?></td>
                            <td scope="row"><?php echo e($str->radiofm); ?></td>
                            <td scope="row"><a href="<?php echo e($str->link); ?>" target=_blank><?php echo e($str->link); ?></a></td>
                            <td scope="row"><?php echo e($str->category); ?></td>
                            <td scope="row"><?php echo e($str->address); ?></td>
                            <td scope="row"><?php echo e($str->city_name); ?></td>
                        <tr>
                        </tbody>
                    </table>
                    <hr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                 
                <hr>
                </div>               
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravelApp\resources\views/layouts/playradio.blade.php ENDPATH**/ ?>