<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\Favourite;

class Radio extends Model
{
    protected $fillable = array('radioname','radiofm','link','city_name', 'stream');

    public function favourite()
    {
    	return $this->hasOne('App\Favourite', 'radios_id', 'id');
    }
}
