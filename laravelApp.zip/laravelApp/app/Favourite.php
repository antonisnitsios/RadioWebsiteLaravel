<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use App\Radio;

class Favourite extends Model
{
	protected $fillable = array('radio_id','radio_radioname','user_id','user_name');
	
	public function user()
	{
		return $this->belongsTo('App\User');
	}    

	public function radio()
	{
		return $this->belongsTo('App\Radio');
	}
}
