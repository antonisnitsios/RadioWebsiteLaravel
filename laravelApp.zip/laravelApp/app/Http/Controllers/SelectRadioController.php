<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Radio;
use App\User;
use App\Favourite;
use Illuminate\Support\Facades\Auth;
use DB;

class SelectRadioController extends Controller
{
	public function addToFavourites(Request $request)
    {
        $radioid = $request->get('id');
        $radioname = $request->get('radioname');
        $userid = $request->get('userid');
        $username = $request->get('username');
        $favouriteradio = Favourite::where('user_id', Auth::user()->id)->get();
		if($radioname == $favouriteradio){
			return redirect()->back()->with('success', 'Ο σταθμός που επιλέξατε έχει προστεθεί ήδη στα αγαπημένα!');
		}else{
			$favourite = new Favourite([
				'radio_id' => $radioid,
				'radio_radioname' => $radioname,
				'user_id' => $userid,
				'user_name' => $username, 
			]);
			$favourite->save();
			return redirect()->back()->with('success', 'Ο σταθμός προστέθηκε στα αγαπημένα σας επιτυχώς!');
		}
	}

    public function getcategory($category){
        $cat = Radio::select('category')->orderby('category', 'asc')->distinct()->get();
        $ct = Radio::select('city_name')->orderby('city_name', 'asc')->distinct()->get();
        $radios = Radio::where('category', $category)->orderby('radioname', 'asc')->get();
        $passing = Radio::select('category')->where('category', $category)->distinct()->get();
        return view('layouts.catradio')->with(['radios' => $radios, 'categories' => $cat, 'cities' => $ct, 'pass' => $passing]);
    }

    public function getcity($city){
        $cat = Radio::select('category')->orderby('category', 'asc')->distinct()->get();
        $ct = Radio::select('city_name')->orderby('city_name', 'asc')->distinct()->get();
        $radios = Radio::where('city_name', $city)->orderby('radioname', 'asc')->get();
        $passing = Radio::select('city_name')->where('city_name', $city)->distinct()->get();
        return view('layouts.ctradio')->with(['radios' => $radios, 'categories' => $cat, 'cities' => $ct, 'pass' => $passing]);
    }

    public function getInternetRadio(){
        $cat = Radio::select('category')->orderby('category', 'asc')->distinct()->get();
        $ct = Radio::select('city_name')->orderby('city_name', 'asc')->distinct()->get();
        $radios = Radio::where('address', 'Internet Radio')->orderby('radioname', 'asc')->get();
        $passing = Radio::select('address')->where('address', 'Internet Radio')->distinct()->get();
        return view('layouts.ctradio')->with(['radios' => $radios, 'categories' => $cat, 'cities' => $ct, 'pass' => $passing]);
    }

    public function getFavourites(){
        $radios = Favourite::where('user_id', Auth::user()->id)->get();
        return view('layouts.favourites')->with(['radios' => $radios]);
    }

    public function searchRadio(Request $request){
        $text = $request->input('txtSearch');
        $radio = Radio::where('radioname', 'like', $text.'%')->where('address', '')->get();
        $category = Radio::select('category')->orderby('category', 'asc')->distinct()->get();
        $city = Radio::select('city_name')->orderby('city_name', 'asc')->distinct()->get();
        $internetradios = Radio::where('radioname', 'like', $text.'%')->where('address', 'Internet Radio')->get();
        return view('layouts.radio')->with(['radios' => $radio, 'internetradios' => $internetradios, 'categories' => $category, 'cities' => $city]);       
    }
}