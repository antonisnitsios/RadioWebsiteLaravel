<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Http\Response;
use App\Radio;
use App\Favourite;
use Illuminate\Support\Facades\Storage;
use Image;
use Illuminate\Support\Facades\Auth;

class RadioController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $category = Radio::select('category')->orderby('category', 'asc')->distinct()->get();
        $city = Radio::select('city_name')->orderby('city_name', 'asc')->distinct()->get();
        $radios = Radio::where('address', '')->orderby('radioname', 'asc')->get();
        $internetradios = Radio::where('address','Internet Radio')->orderby('radioname', 'asc')->get();
        return view('layouts.radio')->with(['radios' => $radios, 'internetradios' => $internetradios, 'categories' => $category, 'cities' => $city]);
    }
    
    public function indexbycategory()
    {   
        $category = Radio::select('category')->orderby('category', 'asc')->distinct()->get();
        $city = Radio::select('city_name')->orderby('city_name', 'asc')->distinct()->get();
        $radios = Radio::where('address', ' ')->orderby('category', 'asc')->get();
        $internetradios = Radio::where('address', 'Internet Radio')->orderby('radioname', 'asc')->get();
        return view('layouts.radio')->with(['radios' => $radios, 'internetradios' => $internetradios, 'categories' => $category, 'cities' => $city]);
    }

    public function indexbyradiocity()
    {   
        $category = Radio::select('category')->orderby('category', 'asc')->distinct()->get();
        $city = Radio::select('city_name')->orderby('city_name', 'asc')->distinct()->get();
        $radios = Radio::where('address', ' ')->orderby('city_name', 'asc')->get();
        $internetradios = Radio::where('address','Internet Radio')->orderby('radioname', 'asc')->get();
        return view('layouts.radio')->with(['radios' => $radios, 'internetradios' => $internetradios, 'categories' => $category, 'cities' => $city]);
    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    public function store(Request $request)
    {
        $r = $request->get('ppp');
        if($r == "radiocity"){
            return redirect()->route('radiocity');
        }elseif($r == "radiocategory"){
            return redirect()->route('radiocategory'); 
        }elseif($r == "radioname"){
            return redirect()->route('radioname');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {   
        $dbid = Radio::where('id', $id)->get();
        if(!isset(Auth::user()->id)){
            return view('layouts.playradioguest')->with(['id' => $dbid]);
        }else{
            return view('layouts.playradio')->with(['id' => $dbid]);
        }
        
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $res=Favourite::find($id)->delete();
        return redirect()->back()->with('success', 'Ο σταθμός αφαιρέθηκε από τα αγαπημένα σας επιτυχώς!');    
    }
}
