<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attribute;
use App\User;
use App\Favourite;
use App\City;
//use App\Http\Controllers\Auth;//
use Illuminate\Support\Facades\Auth;

class PostController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {   
        $attributes = Attribute::where('user_id', Auth::id())->get();
        return view('layouts.created')->with('attributes', $attributes);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('layouts.created');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'phone1' => 'required',
            'capacity' => 'required'
        ]);

        $attribute = new Attribute([
            'phone1'    =>  $request->get('phone1'),
            'phone2'     =>  $request->get('phone2'),
            'facebook'     =>  $request->get('facebook'),
            'linkedin'     =>  $request->get('linkedin'),
            'capacity'     =>  $request->get('capacity'),
            'address'     =>  $request->get('address'),
            'user_id'     =>  $request->get('userid'),
            'user_name'     =>  $request->get('username'), 
        ]);
        $count = Attribute::count('user_id');
        if($count == 0){
            $attribute->save();
            return redirect()->route('attribute.index')->with('success', 'Τα στοιχεία σας καταχωρήθηκαν επιτυχώς!');
        }else{
            return redirect()->route('create')->with('message', 'Έχετε ήδη καταχωρήσει στοιχεία!');
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $attrid = Attribute::where('user_id', $id)->get();
        return view('layouts.update')->with('attributes', $attrid);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validate($request, [
            'phone1' => 'required',
            'capacity' => 'required'
        ]);

        $count = Attribute::count('user_id');
        $attribute = Attribute::where('user_id', $id)->update([
            'phone1'    =>  $request->get('phone1'),
            'phone2'     =>  $request->get('phone2'),
            'facebook'     =>  $request->get('facebook'),
            'linkedin'     =>  $request->get('linkedin'),
            'capacity'     =>  $request->get('capacity'),
            'address'     =>  $request->get('address'),
            'user_id'     =>  $request->get('userid'),
            'user_name'     =>  $request->get('username'),
        ]);
        return redirect()->route('attribute.index')->with('success', 'Τα στοιχεία σας ενημερώθηκαν επιτυχώς!');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $favourite = Favourite::where('user_id', $id)->delete();
        $attributes = Attribute::where('user_id', $id)->delete();
        $account = User::find($id)->delete();
        return redirect()->route('home')->with('success', 'Τα στοιχεία σας διαγράφηκαν');
    }
}
