<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Foundation\Auth\User as Authenticatable;
use App\Attribute;
use App\Favourite;

class User extends Authenticatable 
{
    protected $fillable = array('name','email','password');

    public function attribute()
    {
        return $this->hasOne('App\Attribute', 'user_id', 'id');
    }

    public function favourite()
    {
    	return $this->hasOne('App\Favourite', 'users_id', 'id');
    }
}

