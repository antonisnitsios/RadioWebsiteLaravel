<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App\User;
use App\City;

class Attribute extends Model
{
    protected $fillable = array('phone1','phone2','facebook','linkedin','capacity','address','user_id','user_name');

    public function user()
    {
        return $this->belongsTo('App\User');
    }
}